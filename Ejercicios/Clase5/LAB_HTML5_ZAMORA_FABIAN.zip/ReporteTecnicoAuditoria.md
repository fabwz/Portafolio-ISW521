# Reporte Técnico de Auditoría — HTML5
**Estudiante:** Fabian Zamora Araya  
 

---

## 1.1 — Análisis del problema Div-Soup

### Etiquetas HTML5 semánticas completamente ausentes

| Etiqueta | Propósito esperado

| <header> | Encabezado del sitio con título y subtítulo 
|<nav> | Barra de navegación con los enlaces del menú 
| <main> | Contenido principal de la página 
| <footer> | Pie de página con créditos y copyright 
| <section> | Secciones temáticas (Acerca de, Agenda, Sede, Contacto) 
|<article> | Cada proyecto finalista (EcoSensor Pro, BioFiltro, AgroBot) 
| <aside> | Información complementaria o secundaria 


### ¿Qué es el "Div-Soup" y cuál es su impacto?

El Div-Soup es un antipatrón de diseño en donde se usan <div> para estructurar todo el codigo sin ninguna etiqueta semántica. En este archivo todos los componentes por ejemplo, el encabezado, el menú, secciones de contenido, tarjetas del proyecto, pie de página y textos descriptivos dentro del formulario son <div>. Sus consecuencias son:

- **Mantenimiento difícil:** Un dev nuevo que revise el código no puede saber qué bloque es el encabezado, cuál es la navegación y cuál es el contenido sin leer clase por clase.
- **Escalabilidad reducida:** Al querer agregar nuevas secciones o reorganizar el layout se vuelve arriesgado porque todo depende de clases CSS arbitrarias, no de una estructura lógica.
- **Accesibilidad nula:** Los lectores de pantalla para personas con discapacidad visual no pueden saltar entre partes del documento si esas partes no existen semánticamente.

---

## 1.2 — Análisis del Formulario de Inscripción

### Ausencia de etiquetas <label> vinculadas

Ningún campo del formulario tiene un <label> correctamente asociado. Los textos descriptivos de cada campo son simples <div>. Por ejemplo:

<div>Nombre del equipo o proyecto:</div>
<input type="text" placeholder="Nombre del proyecto">

No existe ningún for en un <label> ni ningún id en los <input>. Sus defectos son:

1. Al hacer clic en el texto descriptivo, el cursor no se posiciona en el campo correspondiente.
2. Para usuarios que navegan con teclado o lectores de pantalla, el campo queda sin nombre accesible, lo que hace imposible saber a qué dato corresponde.

### Ausencia de <fieldset> y <legend>

El formulario no agrupa sus campos de ninguna manera lógica, cuando al menos debería de existir:

- **Datos del equipo:** nombre del proyecto, responsable, correo, teléfono, institución.
- **Detalles del proyecto:** carrera, categoría, descripción, requerimientos especiales.

Cada grupo debería estar dentro de un <fieldset> con un <legend> que describa su propósito, así:

<fieldset>
  <legend>Datos del equipo</legend>
  ...campos...
</fieldset>


Sin esta estructura, el formulario es una lista plana de campos sin jerarquía ni contexto.

### <select> de carrera vs <datalist>

El campo "Carrera o programa académico" usa un <select> cerrado con 9 opciones fijas. Un <datalist> sería mejor por que:

- Permite al usuario escribir libremente y filtrar las sugerencias mientras escribe, en lugar de tener que desplegar una lista y buscar visualmente.
- Permite ingresar un valor que no esté en la lista (por ejemplo una carrera que no aparece entre las opciones), lo cual es más flexible para una feria a nivel nacional.
-  <select> obliga a elegir solo una opción predefinida mientras que <datalist>sugiere opciones pero no restringe la entrada.

<!-- En lugar de esto: -->
<select>
  <option>Ingeniería en Computación</option>
  ...
</select>

<!-- Debería ser: -->
<input type="text" list="carreras" id="carrera" name="carrera">
<datalist id="carreras">
  <option value="Ingeniería en Computación">
  ...
</datalist>


---

## 1.3 — Análisis de la Tabla de Agenda

### Ausencia de <thead>, <tbody> y <tfoot>

La tabla tiene todos sus <tr> al mismo nivel, sin ninguna sección estructural:

<table>
    <tr>
        <th>Hora</th>
        <th>Miércoles 22 Oct</th>
        ...
    </tr>
    <tr>
        <td>7:30 - 8:30</td>
        ...
    </tr>
    ...
</table>

Estas tres secciones no son solo estéticas sino que tienen funciones como:

- **<thead>** Le indica al navegador qué fila es el encabezado. En tablas largas, permite que el encabezado se repita en cada página al imprimir.
- **<tbody>** Agrupa las filas de datos, lo que permite al navegador renderizar el cuerpo de la tabla de forma independiente.
- **<tfoot>** Marca la fila de totales o resumen. En este caso, la fila "Total horas" debería estar aquí. Sin <tfoot>, esa fila no tiene semántica diferenciada del resto de los datos.

### Atributo scope ausente en los <th>

Ningún <th> tiene el atributo scope. Los valores correctos serían:

- scope="col" Para los encabezados de la primera fila (Hora, Miércoles 22 Oct, etc.), ya que describen columnas.
- scope="row" Si hubiera encabezados de fila (por ejemplo, si los horarios fueran <th> en lugar de <td>).

Sin scope, los lectores de pantalla y otras tecnologías de ayuda no pueden asociar correctamente cada celda de datos con su encabezado de columna, lo que hace la tabla incomprensible para alguien con discapacidad visual.

### Ausencia de <caption>

No existe ningún <caption> en la tabla. Este elemento sirve para describir el propósito de la tabla directamente en el documento visible encima de ella. Sus puntos mas importantes son:

- Identifica el contenido de la tabla sin necesidad de leer el <h2> que la rodea.
- Es el primer elemento que leen los lectores de pantalla al encontrar una tabla, dándole contexto inmediato al usuario.
- Mejora la accesibilidad y el SEO de la página.

En este caso debería decir algo como: <caption>Agenda de actividades — Feria Nacional de Innovación Estudiantil 2025</caption>.

---

## 1.4 — Análisis del Elemento <video>

### Falta el atributo poster

<video width="100%">
    <source src="video/feria_presentacion.mp4" type="video/mp4">
</video>
```

El atributo poster define la imagen que se muestra antes de que el usuario reproduzca el video. El que no este causa un problema de Cumulative Layout Shift (CLS), que es una métrica de Core Web Vitals de Google. Cuando el video carga sin dimensiones visuales definidas, el navegador no reserva el espacio correcto en el layout. Cuando el video finalmente carga, empuja el contenido que está debajo, generando un salto visual que penaliza el puntaje de rendimiento del sitio.

### Solo una fuente de video

El elemento <video> tiene solo un <source> con formato video/mp4. Esto es un problema porque no todos los navegadores soportan MP4 con el mismo codec. Lo mejor es incluir al menos dos fuentes alternativas como:

<source src="video/feria_presentacion.mp4" type="video/mp4">
<source src="video/feria_presentacion.webm" type="video/webm">


### Falta el atributo controls

El <video> no tiene el atributo controls, lo que significa que el video se renderiza sin barra de reproducción, sin botón de pausa, sin control de volumen y sin barra de progreso. El usuario no tiene ninguna forma de interactuar con el video. Esto es un problema grave de usabilidad ya que el contenido existe pero es inaccesible para el usuario.

---

## 1.5 — Análisis del iFrame del Mapa

<iframe
    src="https://www.google.com/maps/embed?..."
    width="100%"
    height="420"
    style="border:0;"
    allowfullscreen="">
</iframe>

### Falta loading="lazy"

El iFrame carga el mapa de Google inmediatamente cuando la página se abre, aunque el mapa esté al final del documento y el usuario quizás nunca llegue a verlo. El atributo loading="lazy" instruye al navegador a no cargar el iFrame hasta que el usuario se desplace cerca de él, mejorando el tiempo de carga inicial de la página y el puntaje de rendimiento.

### Falta el atributo sandbox

El iFrame no tiene el atributo sandbox, lo que significa que el contenido embebido de Google Maps se ejecuta con los mismos permisos que la página padre. Esto es un riesgo de seguridad real ya que el atributo sandbox restringe lo que el contenido embebido puede hacer. Para un mapa embebido los valores apropiados serían:

sandbox="allow-scripts allow-same-origin"

Sin sandbox el iframe puede ejecutar scripts, enviar formularios y acceder al DOM de la página principal. Con sandbox se bloquea todo eso y solo se reactiva lo necesario con los allow- específicos.

### Falta el atributo title

No hay atributo title en el <iframe>. Este atributo es necesario para que los lectores de pantalla puedan anunciar el propósito del contenido embebido al usuario. Sin él el lector de pantalla simplemente dice "marco" sin ningún contexto. Debería ser algo como title="Mapa de ubicación del ITCR Campus Cartago".

---

## 1.6 — Análisis del Anidamiento Incorrecto

### Instancias identificadas en el código

**Caso 1 — <div> dentro de <span>**

<span>
    <div>
        <h3>Secretaría de la Feria</h3>
        <div>feria.innovacion@itcr.ac.cr</div>
        <div>Teléfono: 2550-9000 ext. 3100</div>
    </div>
</span>


<span> es un elemento de línea (*inline*). Meter un <div> (elemento de bloque) dentro de él viola el modelo de contenido HTML5, que prohíbe elementos de bloque como hijos de elementos de línea.

**Caso 2 — <div> dentro de <a>**

<a href="https://www.tec.ac.cr">
    <div>
        <div>Portal oficial del ITCR</div>
        <div>www.tec.ac.cr · Campus Cartago</div>
    </div>
</a>

<a> es también un elemento de línea. Meter <div> dentro viola el modelo de contenido porque los elementos de bloque no deberían ir dentro de elementos de línea.

### ¿Por qué el navegador corrige esto y qué problemas causa?

Los navegadores modernos tienen un algoritmo de recuperación de errores que intenta parsear HTML inválido y construir un árbol DOM razonable. Cuando encuentra un <div> dentro de un <span>, puede decidir cerrar el <span> automáticamente antes del <div>, creando una estructura DOM completamente diferente a la que el dev escribió. Esto puede romper selectores CSS que dependen de la jerarquía, hacer que estilos no se apliquen correctamente, y generar comportamientos de layout impredecibles según el navegador.

### ¿Cómo verificarlo con DevTools?

1. Abrir el archivo en Chrome o Edge y presionar F12
2. Ir a la pestaña Elements
3. Comparar el árbol DOM renderizado con el código fuente, si el navegador corrigió el anidamiento, el árbol DOM mostrará una estructura diferente a la del HTML escrito
4. También se puede usar F12, Console y buscar advertencias de parsing, aunque los navegadores modernos puede que no las muestren visualmente. La forma más confiable es pegar el código en https://validator.w3.org y revisar los errores de modelo de contenido reportados.
