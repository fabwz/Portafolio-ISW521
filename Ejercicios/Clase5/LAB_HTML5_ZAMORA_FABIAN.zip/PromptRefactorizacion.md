Eres un desarrollador Frontend Senior con especialización en estándares W3C y accesibilidad web. 
Tu tarea es refactorizar un archivo HTML que fue escrito sin ninguna semántica HTML5, con múltiples 
errores estructurales y de accesibilidad. El archivo corresponde al sitio web de la Feria Nacional 
de Innovación Estudiantil 2025 del ITCR.

El archivo tiene los siguientes problemas identificados en una auditoría técnica:

1. Div-Soup total: el encabezado, navegación, contenido principal, secciones, artículos y pie de 
   página son todos <div>, sin ninguna etiqueta semántica HTML5.
2. Formulario sin semántica: los campos no tienen <label> vinculados con for/id, no hay 
   <fieldset> ni <legend> para agrupar campos, y el select de carrera debería ser un <datalist>.
3. Tabla sin estructura: la tabla de agenda no tiene <thead>, <tbody>, <tfoot>, los <th> no tienen 
   atributo scope y falta el <caption>.
4. Video incompleto: le falta el atributo poster, el atributo controls y solo tiene una fuente 
   <source> en formato mp4.
5. iFrame inseguro: al iframe del mapa le faltan los atributos sandbox, loading="lazy" y title.
6. Anidamiento incorrecto: hay <div> dentro de <span> y <div> dentro de <a> en la sección de contacto.

Debes cumplir estas reglas sin excepción:

1. Reemplazar <div class="encabezado"> por <header>, <div class="menu"> por <nav>, 
   <div class="contenido"> por <main>, y <div class="pie"> por <footer>.
2. Reemplazar las secciones de contenido (<div class="tarjeta"> con id) por <section> 
   y cada tarjeta de proyecto por <article>.
3. Agregar <label for="id"> correctamente vinculado a cada <input>, <select> y <textarea> 
   del formulario, asignando el id correspondiente a cada campo.
4. Envolver los campos del formulario en dos <fieldset>: uno para datos del equipo y otro 
   para detalles del proyecto, cada uno con su <legend>.
5. Reemplazar el <select> de carrera por un <input type="text"> con <datalist> manteniendo 
   todas las opciones existentes.
6. Agregar <thead>, <tbody> y <tfoot> a la tabla. La fila de encabezados va en <thead>, 
   las filas de horario en <tbody> y la fila "Total horas" en <tfoot>.
7. Agregar scope="col" a todos los <th> de la fila de encabezado y un <caption> descriptivo 
   a la tabla.
8. Agregar al elemento <video> los atributos poster="img/poster_feria.jpg" y controls. 
   Agregar una segunda fuente <source> en formato webm.
9. Agregar al <iframe> los atributos: loading="lazy", title="Mapa de ubicación del ITCR 
   Campus Cartago" y sandbox="allow-scripts allow-same-origin".
10. Corregir el anidamiento incorrecto: reemplazar el <span> que contiene <div> en la sección 
    de contacto por un elemento de bloque apropiado, y reemplazar los <div> dentro del <a> 
    por elementos inline o de bloque válidos en ese contexto.
11. No modificar el contenido visible ni los estilos CSS existentes. Solo corregir la estructura HTML.
12. El documento debe conservar el atributo lang="es" en la etiqueta <html>.

Antes de entregar el resultado, verifica internamente que:

- No quede ningún <div class="encabezado">, <div class="menu">, <div class="contenido"> 
  ni <div class="pie"> en el código.
- Cada <input>, <select> y <textarea> tiene un <label> con for que coincide con el id del campo.
- La tabla tiene <thead>, <tbody>, <tfoot>, todos los <th> tienen scope="col" y existe <caption>.
- El <video> tiene controls, poster y dos <source>.
- El <iframe> tiene sandbox, loading="lazy" y title.
- No hay ningún elemento de bloque dentro de <span> ni anidamientos inválidos.

Devuelve únicamente el código HTML completo y corregido, comenzando con <!DOCTYPE html> y 
terminando con </html>. Sin explicaciones, sin comentarios adicionales fuera del código, 
sin bloques de texto antes ni después.
