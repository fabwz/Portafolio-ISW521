# Fase 3 — Validación y Reflexión Final
**Estudiante:** Fabian Zamora Araya
---
## 3.1 — Errores encontrados en el validador W3C
Al pegar el HTML generado por la IA en https://validator.w3.org se obtuvieron los siguientes resultados:
### Error 1 — width="100%" en <video>
**Qué era:** El validador rechaza el uso de % como valor del atributo width en el elemento <video>. El atributo width en HTML solo acepta valores numéricos enteros (píxeles), no porcentajes.
**Corrección aplicada:**
<!-- Antes: -->
<video width="100%" poster="img/poster_feria.jpg" controls>
<!-- Después: -->
<video style="width:100%;" poster="img/poster_feria.jpg" controls>
### Error 2 — width="100%" en `<iframe>
**Qué era:** El mismo problema que el video. El atributo `width` del `<iframe>` tampoco acepta porcentajes, solo valores numéricos.
**Corrección aplicada:**
<!-- Antes: -->
<iframe width="100%" style="border:0;" ...>
<!-- Después: -->
<iframe style="border:0; width:100%;" ...>
```
## 3.2 — Reflexión Final
Lo primero que noté fue que la IA respondió bien a las instrucciones del prompt: aplicó casi todas las restricciones correctamente, reemplazó los <div> por etiquetas semánticas, agregó los <label> con sus id, armó los <fieldset> y corrigió el anidamiento del <span> y el <a>. En ese sentido, el prompt técnico funcionó bien porque era específico y no dejaba mucho espacio para la interpretación.
Al revisar el output. Aunque el resultado se veía bien a primera vista, al pasarlo por el validador W3C aparecieron dos errores que la IA no detectó los cuales eran el uso de width="100%" en el <video> y en el <iframe>, que el estándar HTML no permite en esos atributos. Eso deja que confiar en lo que genera una IA sin revisarlo es un error, porque puede dar código que se ve funcional en el navegador pero que técnicamente no cumple con lo que se espera.
También noté que la IA hizo un cambio que no estaba en las instrucciones: cambió type="text" por type="email" en el campo de correo y type="tel" en el de teléfono. Son buenas mejoras pero no se pidieron, lo que muestra que la IA puede tomar decisiones propias aunque el prompt diga lo contrario.
